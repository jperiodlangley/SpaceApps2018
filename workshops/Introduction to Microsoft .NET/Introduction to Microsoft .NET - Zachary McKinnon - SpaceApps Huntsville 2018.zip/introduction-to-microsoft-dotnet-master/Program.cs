using System;
using System.Threading;

public class Program
{
    public static void Main()
    {
        for (var i = 10; i >= 0; i--)
        {
            if (i > 0)
            {
                Console.WriteLine(i);
                Thread.Sleep(1000);
            }
        }
        Console.WriteLine("Blastoff!");
    }
}
