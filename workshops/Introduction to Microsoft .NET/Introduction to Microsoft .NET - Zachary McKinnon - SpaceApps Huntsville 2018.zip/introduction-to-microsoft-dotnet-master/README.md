# Introduction to Microsoft .NET

This is a code demo for an introduction to Microsoft .NET presentation that was given on 9/19/2018 for Space Apps Workshop.

## What does it do?

This code example is a countdown timer written in .NET Core.  When the code is run, it will begin a countdown from 10 and say "blastoff" when it reaches zero.

## How does it work?

You can build the project by opening a terminal, navigating to the directory where this README exists and running: `dotnet build`

Now that the project is built, you can execute the code by running: `dotnet run`

## Resources
- https://github.com/hsv-dotnet-meetup/introduction-to-microsoft-dotnet
- https://docs.microsoft.com
- https://www.microsoft.com/net/download
- https://code.visualstudio.com
